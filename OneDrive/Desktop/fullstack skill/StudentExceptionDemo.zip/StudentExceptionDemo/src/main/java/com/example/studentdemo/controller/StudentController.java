package com.example.studentdemo.controller;

import org.springframework.web.bind.annotation.*;

import com.example.studentdemo.model.Student;
import com.example.studentdemo.exception.StudentNotFoundException;
import com.example.studentdemo.exception.InvalidInputException;

@RestController
@RequestMapping("/student")
public class StudentController {

    @GetMapping("/{id}")
    public Student getStudent(@PathVariable int id) {

        if(id <= 0) {
            throw new InvalidInputException("Student ID must be positive");
        }

        if(id != 1) {
            throw new StudentNotFoundException("Student with ID " + id + " not found");
        }

        return new Student(1,"Rahul","Computer Science");
    }
}